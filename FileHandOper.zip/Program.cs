﻿using System;
using System.IO;

namespace FileHandlingDemo
{
    class Program
    {
        static string filePath = @"C:\Users\YourUsername\Desktop\demo.txt"; 
        static void Main(string[] args)
        {
            int choice;

            do
            {
                Console.WriteLine("\n=== File Handling Operations ===");
                Console.WriteLine("1. Create File");
                Console.WriteLine("2. Write to File");
                Console.WriteLine("3. Append to File");
                Console.WriteLine("4. Read File");
                Console.WriteLine("5. Copy File");
                Console.WriteLine("6. Move File");
                Console.WriteLine("7. Delete File");
                Console.WriteLine("8. Check if File Exists");
                Console.WriteLine("9. Get File Info");
                Console.WriteLine("0. Exit");
                Console.Write("Enter your choice: ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1: CreateFile(); break;
                    case 2: WriteToFile(); break;
                    case 3: AppendToFile(); break;
                    case 4: ReadFile(); break;
                    case 5: CopyFile(); break;
                    case 6: MoveFile(); break;
                    case 7: DeleteFile(); break;
                    case 8: CheckFileExists(); break;
                    case 9: GetFileInfo(); break;
                    case 0: Console.WriteLine("Exiting..."); break;
                    default: Console.WriteLine("Invalid choice."); break;
                }

            } while (choice != 0);
        }

        static void CreateFile()
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Close();
                    Console.WriteLine("File created successfully.");
                }
                else
                {
                    Console.WriteLine("File already exists.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static void WriteToFile()
        {
            try
            {
                Console.Write("Enter text to write: ");
                string text = Console.ReadLine();
                File.WriteAllText(filePath, text);
                Console.WriteLine("Data written successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static void AppendToFile()
        {
            try
            {
                Console.Write("Enter text to append: ");
                string text = Console.ReadLine();
                File.AppendAllText(filePath, "\n" + text);
                Console.WriteLine("Data appended successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static void ReadFile()
        {
            try
            {
                if (File.Exists(filePath))
                {
                    string data = File.ReadAllText(filePath);
                    Console.WriteLine("File content:\n" + data);
                }
                else
                {
                    Console.WriteLine("File does not exist.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static void CopyFile()
        {
            try
            {
                Console.Write("Enter destination path to copy: ");
                string destPath = Console.ReadLine();
                File.Copy(filePath, destPath, true);
                Console.WriteLine("File copied successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static void MoveFile()
        {
            try
            {
                Console.Write("Enter destination path to move: ");
                string destPath = Console.ReadLine();
                File.Move(filePath, destPath);
                filePath = destPath; // update path
                Console.WriteLine("File moved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static void DeleteFile()
        {
            try
            {
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                    Console.WriteLine("File deleted successfully.");
                }
                else
                {
                    Console.WriteLine("File does not exist.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static void CheckFileExists()
        {
            if (File.Exists(filePath))
            {
                Console.WriteLine("File exists.");
            }
            else
            {
                Console.WriteLine("File does not exist.");
            }
        }

        static void GetFileInfo()
        {
            try
            {
                if (File.Exists(filePath))
                {
                    FileInfo fi = new FileInfo(filePath);
                    Console.WriteLine("Full Name: " + fi.FullName);
                    Console.WriteLine("Name: " + fi.Name);
                    Console.WriteLine("Size: " + fi.Length + " bytes");
                    Console.WriteLine("Created: " + fi.CreationTime);
                    Console.WriteLine("Last Accessed: " + fi.LastAccessTime);
                    Console.WriteLine("Last Modified: " + fi.LastWriteTime);
                }
                else
                {
                    Console.WriteLine("File does not exist.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
